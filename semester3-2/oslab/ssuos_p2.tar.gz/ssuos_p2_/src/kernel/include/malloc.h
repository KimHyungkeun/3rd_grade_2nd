#ifndef		__MALLOC_H__
#define		__MALLOC_H__

/*
void* malloc(unsigned size);
void free(void* buf);
*/

void Init_Paging(void);

#endif
